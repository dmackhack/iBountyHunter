//
//  Fugitive.m
//  iBountyHunter
//
//  Created by Dan Pilone on 2/20/11.
//  Copyright (c) 2011 Element 84, LLC. All rights reserved.
//

#import "Fugitive.h"


@implementation Fugitive
@dynamic name;
@dynamic bounty;
@dynamic fugitiveID;
@dynamic desc;

@end
