//
//  iBountyHunterAppDelegate_iPad.m
//  iBountyHunter
//
//  Created by Dan Pilone on 2/14/11.
//  Copyright 2011 Element 84, LLC. All rights reserved.
//

#import "iBountyHunterAppDelegate_iPad.h"

@implementation iBountyHunterAppDelegate_iPad

- (void)dealloc
{
	[super dealloc];
}

@end
