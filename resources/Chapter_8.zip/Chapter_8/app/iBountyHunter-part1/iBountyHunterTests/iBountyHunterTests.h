//
//  iBountyHunterTests.h
//  iBountyHunterTests
//
//  Created by Dan Pilone on 2/14/11.
//  Copyright 2011 Element 84, LLC. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface iBountyHunterTests : SenTestCase {
@private
    
}

@end
